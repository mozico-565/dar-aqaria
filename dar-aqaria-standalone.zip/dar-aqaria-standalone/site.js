(() => {
  const initIcons = () => { if (window.lucide) window.lucide.createIcons({attrs:{'stroke-width':1.9}}); };
  initIcons();
  window.addEventListener('load', initIcons);
  document.querySelectorAll('img[data-fallback]').forEach(img => {
    img.addEventListener('error', () => { if (img.dataset.fallback && img.src !== img.dataset.fallback) img.src = img.dataset.fallback; }, {once:true});
  });
  const toast = document.getElementById('demo-toast'); let timer;
  document.querySelectorAll('[data-demo-whatsapp]').forEach(btn => btn.addEventListener('click', () => {
    if(!toast) return; toast.classList.add('show'); clearTimeout(timer); timer=setTimeout(()=>toast.classList.remove('show'),3600);
  }));
  document.querySelectorAll('.mobile-menu a').forEach(a=>a.addEventListener('click',()=>{const d=a.closest('details'); if(d)d.open=false;}));
})();
